package com.gl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.gl.connection.MyConnection;
import com.gl.model.Employee;

public class EmployeeDao {
	
	Connection cons;
	Statement stmt;
	PreparedStatement pstmt;
	ResultSet result;
	MyConnection mCon;
	ArrayList <Employee> emloyees;
	
	public EmployeeDao() {
		emloyees=new ArrayList<>();
		mCon=new MyConnection();
	}
	
	public boolean insertEmployeeRecord(Employee employee) throws Exception {
		boolean flag=false;
		cons=mCon.myConnection();
		pstmt=cons.prepareStatement("insert into employee values(?,?,?,?)");
		pstmt.setInt(1, employee.getId());
		pstmt.setString(2, employee.getName());
		pstmt.setString(3, employee.getEmailId());
		pstmt.setString(4, employee.getPhoneNumber());
		pstmt.execute();
		flag=true;
		return flag;
	}
	
	public boolean modifyEmailIdColumn() throws Exception {
		boolean flag=false;
		cons=mCon.myConnection();
		pstmt=cons.prepareStatement("alter table employee modify Email_Id varchar(30)");
		pstmt.execute();
		flag=true;
		return flag; 
	}
	
	public boolean updateEmployeeRecord(Employee employee) throws Exception{
		boolean flag=false;
		cons=mCon.myConnection();
		pstmt=cons.prepareStatement("update employee set Name=?, Phone_Number=? where Id=?");
		pstmt.setString(1, employee.getName());
		pstmt.setString(2, employee.getPhoneNumber());
		pstmt.setInt(3, employee.getId());
		
		pstmt.execute();
		flag=true;
		return flag;
	}
	
	public boolean deleteEmployeeByIdDAO(int eId) throws Exception{
		boolean flag=false;
		cons=mCon.myConnection();
		
			pstmt=cons.prepareStatement("delete from employee where id = ? ");
			pstmt.setInt(1, eId);
			pstmt.execute();
		
		return flag=true;
	}
	
	public boolean removeAllRecordsDao() throws Exception{
		boolean flag=false;
		cons=mCon.myConnection();
		
			pstmt=cons.prepareStatement("delete from employee");
			pstmt.execute();
		
		return flag=true;
	}
	
	public ArrayList<Employee> getAllEmployeeDAO() throws Exception{
		cons=mCon.myConnection();
		int id;
		String name, email_Id, phone_Number;
		
			stmt=cons.createStatement();//Creating statement
			result=stmt.executeQuery("select*from employee");//Fetching results from database
			if(result==null) System.out.println("No Records");
			while(result.next()) {
				id=result.getInt(1);
				name=result.getString(2);
				email_Id=result.getString(3);
				phone_Number=result.getString(4);
				Employee emp=new Employee(id,name, email_Id, phone_Number);
				emloyees.add(emp);	
			}
		
		return emloyees;
	}
}
