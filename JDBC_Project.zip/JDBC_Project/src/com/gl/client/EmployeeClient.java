package com.gl.client;

public class EmployeeClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		EmployeeDBConnection employeeDBConnection= new EmployeeDBConnection();
		employeeDBConnection.showMenu();
	}

}
