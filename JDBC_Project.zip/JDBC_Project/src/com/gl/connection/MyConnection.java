package com.gl.connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class MyConnection {
	Connection con;//is interface
	String url= "jdbc:mysql://localhost:3306/employee_details";
	String user ="root";
	String password ="Sajida@02";
	
	public Connection myConnection() throws Exception{
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection(url,user,password);
		
		return con;
	}
}
