package com.gl.service;

import java.util.ArrayList;

import com.gl.dao.EmployeeDao;
import com.gl.model.Employee;

public class EmployeeService {
	
	EmployeeDao employeeDao;
	
	public EmployeeService() {
		employeeDao= new EmployeeDao();
	}
	public ArrayList<Employee> getAllEmployeeSvc() throws Exception{
		ArrayList<Employee> employees;
		employees=employeeDao.getAllEmployeeDAO();
		return employees;
	}
	
	public boolean insertEmployeeSVC(Employee employees) throws Exception{
		boolean flag=false;
		flag=employeeDao.insertEmployeeRecord(employees);
		return flag;
	}
	
	public boolean modifyEmailIdColumn() throws Exception {
		boolean flag=false;
		flag=employeeDao.modifyEmailIdColumn();
		return flag;
	}
	
	public boolean updateEmployeeSVC(Employee employeeUpdate) throws Exception{
		boolean flag=false;
		flag=employeeDao.updateEmployeeRecord(employeeUpdate);
		return flag;
	}
	
	public boolean deleteEmployeeByIdSVC(int eId)throws Exception {
		boolean flag=false;
		flag=employeeDao.deleteEmployeeByIdDAO(eId);
		return flag;
	}
	public boolean removeAllRecordsSVC() throws Exception{
		boolean flag=false;
		flag=employeeDao.removeAllRecordsDao();
		return flag;
	}
}
